import numpy as np
import pandas as pd

def clean_dataframe(df, target_column):
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    df = df.replace([np.inf, -np.inf], np.nan).drop_duplicates()
    df = df.dropna(axis=1, how="all")
    if target_column not in df.columns:
        raise ValueError(f"Target column '{target_column}' not found.")
    return df

def make_binary_target(y):
    s = y.astype(str).str.strip()
    return s.apply(lambda x: "Normal" if x.lower() in {"normal","benign","0","false"} else "Attack")
