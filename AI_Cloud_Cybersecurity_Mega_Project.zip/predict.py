import joblib
from config import MODEL_DIR

def threat_score(prediction, anomaly):
    score=15
    if str(prediction).lower()=="attack": score+=65
    if anomaly: score+=20
    return min(score,100)

def predict_dataframe(df):
    model=joblib.load(MODEL_DIR/"best_ml_model.joblib")
    prep=joblib.load(MODEL_DIR/"anomaly_preprocessor.joblib")
    iso=joblib.load(MODEL_DIR/"isolation_forest.joblib")
    pred=model.predict(df)
    anomaly=iso.predict(prep.transform(df))==-1
    out=df.copy()
    out["prediction"]=pred
    out["anomaly"]=anomaly
    out["risk_score"]=[threat_score(p,a) for p,a in zip(pred,anomaly)]
    out["alert"]=out["risk_score"].apply(lambda x:"HIGH" if x>=80 else ("MEDIUM" if x>=50 else "LOW"))
    return out
