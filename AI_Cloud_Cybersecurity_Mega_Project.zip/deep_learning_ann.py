# Optional deep-learning module
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping

def build_ann(input_dim):
    model=Sequential([
        Dense(128,activation="relu",input_shape=(input_dim,)),
        Dropout(0.25),
        Dense(64,activation="relu"),
        Dropout(0.20),
        Dense(1,activation="sigmoid")
    ])
    model.compile(optimizer="adam",loss="binary_crossentropy",metrics=["accuracy"])
    return model

# Example:
# model=build_ann(X_train.shape[1])
# model.fit(X_train,y_train,validation_split=0.2,epochs=30,batch_size=64,
#           callbacks=[EarlyStopping(patience=5,restore_best_weights=True)])
