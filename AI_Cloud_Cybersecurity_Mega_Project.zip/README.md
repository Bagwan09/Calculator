# AI-Based Intelligent Cloud Cybersecurity System

Mega Project combining AI/ML, Cyber Security and Cloud Computing.

Modules:
1. ML intrusion detection and attack classification
2. Anomaly detection
3. ANN deep-learning module
4. Threat/risk scoring and alerts
5. Streamlit security dashboard
6. Optional cloud deployment

Quick start:
1. Install Python 3.10+.
2. Run `pip install -r requirements.txt`
3. Put your authorized/public dataset at `data/network_traffic.csv`.
4. The CSV must contain a target column named `label`.
5. Run `python train.py`
6. Run `streamlit run app.py`
