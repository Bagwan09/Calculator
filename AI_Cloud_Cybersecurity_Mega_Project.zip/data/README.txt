Place your authorized/public cybersecurity CSV here as network_traffic.csv.
Required target column: label
Remaining columns: network/security features.
