from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data" / "network_traffic.csv"
MODEL_DIR = BASE_DIR / "models"
TARGET_COLUMN = "label"
TEST_SIZE = 0.20
RANDOM_STATE = 42
