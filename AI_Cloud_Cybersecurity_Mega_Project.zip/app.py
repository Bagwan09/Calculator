import json, pandas as pd, streamlit as st
from config import MODEL_DIR
from predict import predict_dataframe
st.set_page_config(page_title="Cloud Cybersecurity AI",layout="wide")
st.title("AI-Based Intelligent Cloud Cybersecurity System")
st.caption("ML Intrusion Detection | Anomaly Analysis | Threat Risk Scoring")
meta=MODEL_DIR/"metadata.json"
if not meta.exists():
    st.warning("Train the models first: put data/network_traffic.csv in the project and run python train.py")
    st.stop()
metadata=json.load(open(meta))
st.sidebar.write("Best model:",metadata["best_model"])
uploaded=st.file_uploader("Upload network traffic CSV",type=["csv"])
if uploaded:
    data=pd.read_csv(uploaded)
    if metadata["target_column"] in data.columns:
        data=data.drop(columns=[metadata["target_column"]])
    try:
        result=predict_dataframe(data)
        c1,c2,c3,c4=st.columns(4)
        c1.metric("Total Records",len(result))
        c2.metric("Attacks",int((result.prediction.astype(str).str.lower()=="attack").sum()))
        c3.metric("Anomalies",int(result.anomaly.sum()))
        c4.metric("High Risk",int((result.risk_score>=80).sum()))
        st.subheader("Threat Results")
        st.dataframe(result,use_container_width=True)
        st.subheader("Risk Distribution")
        st.bar_chart(result.alert.value_counts())
        st.subheader("Model Comparison")
        st.dataframe(pd.DataFrame(metadata["results"]).T)
    except Exception as e:
        st.error(str(e))
else:
    st.info("Upload a CSV with the same feature structure used during training.")
