# Cloud Deployment Plan
1. Create a small Linux VM on AWS/Azure/GCP.
2. Install Python and dependencies.
3. Copy the trained project.
4. Run the Streamlit dashboard.
5. Restrict access using cloud firewall/security groups.
6. Add authentication before public exposure.
7. Monitor logs and resources.

Cloud deployment is optional for the academic prototype; local development is sufficient for model training.
