import json, warnings
warnings.filterwarnings("ignore")
import joblib, pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier
from config import DATA_FILE, MODEL_DIR, TARGET_COLUMN, TEST_SIZE, RANDOM_STATE
from utils import clean_dataframe, make_binary_target

def preprocessor(X):
    num = X.select_dtypes(include=["number","bool"]).columns.tolist()
    cat = [c for c in X.columns if c not in num]
    parts=[]
    if num:
        parts.append(("num", Pipeline([("imp",SimpleImputer(strategy="median")),("scale",StandardScaler())]), num))
    if cat:
        parts.append(("cat", Pipeline([("imp",SimpleImputer(strategy="most_frequent")),("oh",OneHotEncoder(handle_unknown="ignore"))]), cat))
    return ColumnTransformer(parts)

def score(y,p):
    return {
        "accuracy":round(accuracy_score(y,p),4),
        "precision":round(precision_score(y,p,average="weighted",zero_division=0),4),
        "recall":round(recall_score(y,p,average="weighted",zero_division=0),4),
        "f1":round(f1_score(y,p,average="weighted",zero_division=0),4)
    }

if __name__=="__main__":
    if not DATA_FILE.exists():
        raise FileNotFoundError("Put your CSV at data/network_traffic.csv")
    MODEL_DIR.mkdir(exist_ok=True)
    df=clean_dataframe(pd.read_csv(DATA_FILE),TARGET_COLUMN)
    X=df.drop(columns=[TARGET_COLUMN])
    y=make_binary_target(df[TARGET_COLUMN])
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=TEST_SIZE,random_state=RANDOM_STATE,stratify=y)
    models={
        "Decision Tree":DecisionTreeClassifier(random_state=RANDOM_STATE,class_weight="balanced"),
        "Random Forest":RandomForestClassifier(n_estimators=200,random_state=RANDOM_STATE,class_weight="balanced",n_jobs=-1),
        "Logistic Regression":LogisticRegression(max_iter=1500,class_weight="balanced")
    }
    results={}; best=None; bestf=-1
    for name,est in models.items():
        pipe=Pipeline([("prep",preprocessor(Xtr)),("model",est)])
        pipe.fit(Xtr,ytr); pred=pipe.predict(Xte)
        results[name]=score(yte,pred)
        if results[name]["f1"]>bestf:
            bestf=results[name]["f1"]; best=name
            joblib.dump(pipe,MODEL_DIR/"best_ml_model.joblib")
    prep=preprocessor(Xtr); Xt=prep.fit_transform(Xtr)
    iso=IsolationForest(n_estimators=200,random_state=RANDOM_STATE,contamination="auto")
    iso.fit(Xt)
    joblib.dump(prep,MODEL_DIR/"anomaly_preprocessor.joblib")
    joblib.dump(iso,MODEL_DIR/"isolation_forest.joblib")
    json.dump({"target_column":TARGET_COLUMN,"classes":sorted(y.unique().tolist()),"best_model":best,"results":results},
              open(MODEL_DIR/"metadata.json","w"),indent=2)
    print(json.dumps(results,indent=2))
    print("Best model:",best)
